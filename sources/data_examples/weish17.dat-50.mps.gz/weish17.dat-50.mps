* ENCODING=ISO-8859-1
NAME          weish17.dat-50
ROWS
 N  cost    
 L  KL0     
 L  KL1     
 L  KL2     
 L  KF0     
 L  KF1     
 L  I0      
 L  I1      
 L  I2      
 L  I3      
 L  I4      
 L  I5      
 L  I6      
 L  I7      
 L  I8      
 L  I9      
 L  I10     
 L  I11     
 L  I12     
 L  I13     
 L  I14     
 L  I15     
 L  I16     
 L  I17     
 L  I18     
 L  I19     
 L  I20     
 L  I21     
 L  I22     
 L  I23     
 L  I24     
 L  I25     
 L  I26     
 L  I27     
 L  I28     
 L  I29     
 L  I30     
 L  I31     
 L  I32     
 L  I33     
 L  I34     
 L  I35     
 L  I36     
 L  I37     
 L  I38     
 L  I39     
 L  I40     
 L  I41     
 L  I42     
 L  I43     
 L  I44     
 L  I45     
 L  I46     
 L  I47     
 L  I48     
 L  I49     
 L  I50     
 L  I51     
 L  I52     
 L  I53     
 L  I54     
 L  I55     
 L  I56     
 L  I57     
 L  I58     
 L  I59     
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x0        KL0                             7
    x0        KL1                             8
    x0        KL2                             3
    x0        I0                              1
    x1        KL1                            66
    x1        KL2                            74
    x1        I1                              1
    x2        KL0                            30
    x2        KL1                            98
    x2        KL2                            88
    x2        I2                              1
    x3        KL0                            22
    x3        KL1                            50
    x3        KL2                            50
    x3        I3                              1
    x4        KL0                            80
    x4        KL2                            55
    x4        I4                              1
    x5        KL0                            94
    x5        KL1                            30
    x5        KL2                            19
    x5        I5                              1
    x6        KL0                            11
    x6        I6                              1
    x7        KL0                            81
    x7        KL1                            88
    x7        KL2                             6
    x7        I7                              1
    x8        KL0                            70
    x8        KL1                            15
    x8        KL2                            30
    x8        I8                              1
    x9        KL0                            64
    x9        KL1                            37
    x9        KL2                            62
    x9        I9                              1
    x10       KL0                            59
    x10       KL1                            26
    x10       KL2                            17
    x10       I10                             1
    x11       KL0                            18
    x11       KL1                            72
    x11       KL2                            81
    x11       I11                             1
    x12       KL1                            61
    x12       KL2                            25
    x12       I12                             1
    x13       KL0                            36
    x13       KL1                            57
    x13       KL2                            46
    x13       I13                             1
    x14       KL0                             3
    x14       KL1                            17
    x14       KL2                            67
    x14       I14                             1
    x15       KL0                             8
    x15       KL1                            27
    x15       KL2                            28
    x15       I15                             1
    x16       KL0                            15
    x16       KL1                            83
    x16       KL2                            36
    x16       I16                             1
    x17       KL0                            42
    x17       KL1                             3
    x17       KL2                             8
    x17       I17                             1
    x18       KL0                             9
    x18       KL1                             9
    x18       KL2                             1
    x18       I18                             1
    x19       KL1                            66
    x19       KL2                            52
    x19       I19                             1
    x20       KL0                            42
    x20       KL1                            97
    x20       KL2                            19
    x20       I20                             1
    x21       KL0                            47
    x21       KL1                            42
    x21       KL2                            37
    x21       I21                             1
    x22       KL0                            52
    x22       KL1                             2
    x22       KL2                            27
    x22       I22                             1
    x23       KL0                            32
    x23       KL1                            44
    x23       KL2                            62
    x23       I23                             1
    x24       KL0                            26
    x24       KL1                            71
    x24       KL2                            39
    x24       I24                             1
    x25       KL0                            48
    x25       KL1                            11
    x25       KL2                            84
    x25       I25                             1
    x26       KL0                            55
    x26       KL1                            25
    x26       KL2                            16
    x26       I26                             1
    x27       KL0                             6
    x27       KL1                            74
    x27       KL2                            14
    x27       I27                             1
    x28       KL0                            29
    x28       KL1                            90
    x28       KL2                            21
    x28       I28                             1
    x29       KL0                            84
    x29       KL1                            20
    x29       KL2                             5
    x29       I29                             1
    x30       KL0                             2
    x30       KL2                            60
    x30       I30                             1
    x31       KL0                             4
    x31       KL1                            38
    x31       KL2                            82
    x31       I31                             1
    x32       KL0                            18
    x32       KL1                            33
    x32       KL2                            72
    x32       I32                             1
    x33       KL0                            56
    x33       KL1                            14
    x33       KL2                            89
    x33       I33                             1
    x34       KL0                             7
    x34       KL1                             9
    x34       KL2                            16
    x34       I34                             1
    x35       KL0                            29
    x35       KL1                            23
    x35       KL2                             5
    x35       I35                             1
    x36       KL0                            93
    x36       KL1                            12
    x36       KL2                            29
    x36       I36                             1
    x37       KL0                            44
    x37       KL1                            58
    x37       KL2                             7
    x37       I37                             1
    x38       KL0                            71
    x38       KL1                             6
    x38       KL2                            80
    x38       I38                             1
    x39       KL0                             3
    x39       KL1                            14
    x39       KL2                            97
    x39       I39                             1
    x40       KL0                            86
    x40       KL1                            78
    x40       KL2                            41
    x40       I40                             1
    x41       KL0                            66
    x41       KL2                            46
    x41       I41                             1
    x42       KL0                            31
    x42       KL1                            12
    x42       KL2                            15
    x42       I42                             1
    x43       KL0                            65
    x43       KL1                            99
    x43       KL2                            92
    x43       I43                             1
    x44       KL1                            84
    x44       KL2                            51
    x44       I44                             1
    x45       KL0                            79
    x45       KL1                            31
    x45       KL2                            76
    x45       I45                             1
    x46       KL0                            20
    x46       KL1                            16
    x46       KL2                            57
    x46       I46                             1
    x47       KL0                            65
    x47       KL1                             7
    x47       KL2                            90
    x47       I47                             1
    x48       KL0                            52
    x48       KL1                            33
    x48       KL2                            10
    x48       I48                             1
    x49       KL0                            13
    x49       KL1                            20
    x49       KL2                            37
    x49       I49                             1
    x50       KL0                            48
    x50       KL1                             5
    x50       KL2                            25
    x50       I50                             1
    x51       KL0                            14
    x51       KL1                            18
    x51       KL2                            93
    x51       I51                             1
    x52       KL0                             5
    x52       KL1                            96
    x52       KL2                             5
    x52       I52                             1
    x53       KL0                            72
    x53       KL1                            63
    x53       KL2                            39
    x53       I53                             1
    x54       KL0                            14
    x54       KL1                            31
    x54       I54                             1
    x55       KL0                            39
    x55       KL2                            97
    x55       I55                             1
    x56       KL0                            46
    x56       KL1                            70
    x56       KL2                             6
    x56       I56                             1
    x57       KL0                            27
    x57       KL1                             4
    x57       KL2                            96
    x57       I57                             1
    x58       KL0                            11
    x58       KL1                            66
    x58       KL2                             2
    x58       I58                             1
    x59       KL0                            91
    x59       KL1                             9
    x59       KL2                            81
    x59       I59                             1
    y0        cost                          360
    y0        KF0                            21
    y0        KF1                            94
    y0        I0                              1
    y1        cost                           83
    y1        KF0                            40
    y1        KF1                            86
    y1        I1                              1
    y2        cost                           59
    y2        KF1                            80
    y2        I2                              1
    y3        cost                          130
    y3        KF0                             6
    y3        KF1                            92
    y3        I3                              1
    y4        cost                          431
    y4        KF0                            82
    y4        KF1                            31
    y4        I4                              1
    y5        cost                           67
    y5        KF0                            91
    y5        KF1                            17
    y5        I5                              1
    y6        cost                          230
    y6        KF0                            43
    y6        KF1                            65
    y6        I6                              1
    y7        cost                           52
    y7        KF0                            30
    y7        KF1                            51
    y7        I7                              1
    y8        cost                           93
    y8        KF0                            62
    y8        KF1                            46
    y8        I8                              1
    y9        cost                          125
    y9        KF0                            91
    y9        KF1                            66
    y9        I9                              1
    y10       cost                          670
    y10       KF0                            10
    y10       KF1                            44
    y10       I10                             1
    y11       cost                          892
    y11       KF0                            41
    y11       KF1                             3
    y11       I11                             1
    y12       cost                          600
    y12       KF0                            12
    y12       KF1                            26
    y12       I12                             1
    y13       cost                           38
    y13       KF0                             4
    y13       I13                             1
    y14       cost                           48
    y14       KF0                            80
    y14       KF1                            39
    y14       I14                             1
    y15       cost                          147
    y15       KF0                            77
    y15       KF1                            20
    y15       I15                             1
    y16       cost                           78
    y16       KF0                            98
    y16       KF1                            11
    y16       I16                             1
    y17       cost                          256
    y17       KF0                            50
    y17       KF1                             6
    y17       I17                             1
    y18       cost                           63
    y18       KF0                            78
    y18       KF1                            55
    y18       I18                             1
    y19       cost                           17
    y19       KF0                            35
    y19       KF1                            70
    y19       I19                             1
    y20       cost                          120
    y20       KF0                             7
    y20       KF1                            11
    y20       I20                             1
    y21       cost                          164
    y21       KF0                             1
    y21       KF1                            75
    y21       I21                             1
    y22       cost                          432
    y22       KF0                            96
    y22       KF1                            82
    y22       I22                             1
    y23       cost                           35
    y23       KF0                            67
    y23       KF1                            35
    y23       I23                             1
    y24       cost                           92
    y24       KF0                            85
    y24       KF1                            47
    y24       I24                             1
    y25       cost                          110
    y25       KF0                             4
    y25       KF1                            99
    y25       I25                             1
    y26       cost                           22
    y26       KF0                            23
    y26       KF1                             5
    y26       I26                             1
    y27       cost                           42
    y27       KF0                            38
    y27       KF1                            14
    y27       I27                             1
    y28       cost                           50
    y28       KF0                             2
    y28       KF1                            23
    y28       I28                             1
    y29       cost                          323
    y29       KF0                            57
    y29       KF1                            38
    y29       I29                             1
    y30       cost                          514
    y30       KF0                             4
    y30       KF1                            94
    y30       I30                             1
    y31       cost                           28
    y31       KF0                            53
    y31       KF1                            66
    y31       I31                             1
    y32       cost                           87
    y32       KF1                            64
    y32       I32                             1
    y33       cost                           73
    y33       KF0                            33
    y33       KF1                            27
    y33       I33                             1
    y34       cost                           78
    y34       KF0                             2
    y34       KF1                            77
    y34       I34                             1
    y35       cost                           15
    y35       KF0                            25
    y35       KF1                            50
    y35       I35                             1
    y36       cost                           26
    y36       KF0                            14
    y36       KF1                            28
    y36       I36                             1
    y37       cost                           78
    y37       KF0                            97
    y37       KF1                            25
    y37       I37                             1
    y38       cost                          210
    y38       KF0                            87
    y38       KF1                            61
    y38       I38                             1
    y39       cost                           36
    y39       KF0                            42
    y39       KF1                            10
    y39       I39                             1
    y40       cost                           85
    y40       KF0                            15
    y40       KF1                            30
    y40       I40                             1
    y41       cost                          189
    y41       KF0                            65
    y41       KF1                            15
    y41       I41                             1
    y42       cost                          274
    y42       KF0                            19
    y42       KF1                            12
    y42       I42                             1
    y43       cost                           43
    y43       KF0                            83
    y43       KF1                            24
    y43       I43                             1
    y44       cost                           33
    y44       KF0                            67
    y44       KF1                            90
    y44       I44                             1
    y45       cost                           10
    y45       KF0                            70
    y45       KF1                            25
    y45       I45                             1
    y46       cost                           19
    y46       KF0                            80
    y46       KF1                            39
    y46       I46                             1
    y47       cost                          389
    y47       KF0                            39
    y47       KF1                            47
    y47       I47                             1
    y48       cost                          276
    y48       KF0                             9
    y48       KF1                            98
    y48       I48                             1
    y49       cost                          312
    y49       KF0                             5
    y49       KF1                            83
    y49       I49                             1
    y50       cost                           94
    y50       KF0                            41
    y50       KF1                            56
    y50       I50                             1
    y51       cost                           68
    y51       KF0                            31
    y51       KF1                            36
    y51       I51                             1
    y52       cost                           73
    y52       KF0                            36
    y52       KF1                             6
    y52       I52                             1
    y53       cost                          192
    y53       KF0                            15
    y53       KF1                            66
    y53       I53                             1
    y54       cost                           41
    y54       KF0                            30
    y54       KF1                            89
    y54       I54                             1
    y55       cost                          163
    y55       KF0                            87
    y55       KF1                            45
    y55       I55                             1
    y56       cost                           16
    y56       KF0                            28
    y56       KF1                            38
    y56       I56                             1
    y57       cost                           40
    y57       KF0                            13
    y57       KF1                             1
    y57       I57                             1
    y58       cost                          195
    y58       KF0                            40
    y58       KF1                            18
    y58       I58                             1
    y59       cost                          138
    y59       KF1                            88
    y59       I59                             1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       KL0                          2090
    rhs       KL1                          2200
    rhs       KL2                          1190
    rhs       KF0                          2460
    rhs       KF1                          2320
    rhs       I0                              1
    rhs       I1                              1
    rhs       I2                              1
    rhs       I3                              1
    rhs       I4                              1
    rhs       I5                              1
    rhs       I6                              1
    rhs       I7                              1
    rhs       I8                              1
    rhs       I9                              1
    rhs       I10                             1
    rhs       I11                             1
    rhs       I12                             1
    rhs       I13                             1
    rhs       I14                             1
    rhs       I15                             1
    rhs       I16                             1
    rhs       I17                             1
    rhs       I18                             1
    rhs       I19                             1
    rhs       I20                             1
    rhs       I21                             1
    rhs       I22                             1
    rhs       I23                             1
    rhs       I24                             1
    rhs       I25                             1
    rhs       I26                             1
    rhs       I27                             1
    rhs       I28                             1
    rhs       I29                             1
    rhs       I30                             1
    rhs       I31                             1
    rhs       I32                             1
    rhs       I33                             1
    rhs       I34                             1
    rhs       I35                             1
    rhs       I36                             1
    rhs       I37                             1
    rhs       I38                             1
    rhs       I39                             1
    rhs       I40                             1
    rhs       I41                             1
    rhs       I42                             1
    rhs       I43                             1
    rhs       I44                             1
    rhs       I45                             1
    rhs       I46                             1
    rhs       I47                             1
    rhs       I48                             1
    rhs       I49                             1
    rhs       I50                             1
    rhs       I51                             1
    rhs       I52                             1
    rhs       I53                             1
    rhs       I54                             1
    rhs       I55                             1
    rhs       I56                             1
    rhs       I57                             1
    rhs       I58                             1
    rhs       I59                             1
BOUNDS
 BV bnd       x0      
 BV bnd       x1      
 BV bnd       x2      
 BV bnd       x3      
 BV bnd       x4      
 BV bnd       x5      
 BV bnd       x6      
 BV bnd       x7      
 BV bnd       x8      
 BV bnd       x9      
 BV bnd       x10     
 BV bnd       x11     
 BV bnd       x12     
 BV bnd       x13     
 BV bnd       x14     
 BV bnd       x15     
 BV bnd       x16     
 BV bnd       x17     
 BV bnd       x18     
 BV bnd       x19     
 BV bnd       x20     
 BV bnd       x21     
 BV bnd       x22     
 BV bnd       x23     
 BV bnd       x24     
 BV bnd       x25     
 BV bnd       x26     
 BV bnd       x27     
 BV bnd       x28     
 BV bnd       x29     
 BV bnd       x30     
 BV bnd       x31     
 BV bnd       x32     
 BV bnd       x33     
 BV bnd       x34     
 BV bnd       x35     
 BV bnd       x36     
 BV bnd       x37     
 BV bnd       x38     
 BV bnd       x39     
 BV bnd       x40     
 BV bnd       x41     
 BV bnd       x42     
 BV bnd       x43     
 BV bnd       x44     
 BV bnd       x45     
 BV bnd       x46     
 BV bnd       x47     
 BV bnd       x48     
 BV bnd       x49     
 BV bnd       x50     
 BV bnd       x51     
 BV bnd       x52     
 BV bnd       x53     
 BV bnd       x54     
 BV bnd       x55     
 BV bnd       x56     
 BV bnd       x57     
 BV bnd       x58     
 BV bnd       x59     
 BV bnd       y0      
 BV bnd       y1      
 BV bnd       y2      
 BV bnd       y3      
 BV bnd       y4      
 BV bnd       y5      
 BV bnd       y6      
 BV bnd       y7      
 BV bnd       y8      
 BV bnd       y9      
 BV bnd       y10     
 BV bnd       y11     
 BV bnd       y12     
 BV bnd       y13     
 BV bnd       y14     
 BV bnd       y15     
 BV bnd       y16     
 BV bnd       y17     
 BV bnd       y18     
 BV bnd       y19     
 BV bnd       y20     
 BV bnd       y21     
 BV bnd       y22     
 BV bnd       y23     
 BV bnd       y24     
 BV bnd       y25     
 BV bnd       y26     
 BV bnd       y27     
 BV bnd       y28     
 BV bnd       y29     
 BV bnd       y30     
 BV bnd       y31     
 BV bnd       y32     
 BV bnd       y33     
 BV bnd       y34     
 BV bnd       y35     
 BV bnd       y36     
 BV bnd       y37     
 BV bnd       y38     
 BV bnd       y39     
 BV bnd       y40     
 BV bnd       y41     
 BV bnd       y42     
 BV bnd       y43     
 BV bnd       y44     
 BV bnd       y45     
 BV bnd       y46     
 BV bnd       y47     
 BV bnd       y48     
 BV bnd       y49     
 BV bnd       y50     
 BV bnd       y51     
 BV bnd       y52     
 BV bnd       y53     
 BV bnd       y54     
 BV bnd       y55     
 BV bnd       y56     
 BV bnd       y57     
 BV bnd       y58     
 BV bnd       y59     
ENDATA
